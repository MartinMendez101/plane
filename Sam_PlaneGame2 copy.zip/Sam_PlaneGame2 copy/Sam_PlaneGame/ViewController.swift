//
//  ViewController.swift
//  Sam_PlaneGame
//
//  Created by user147336 on 12/21/18.
//  Copyright © 2018 Sam. All rights reserved.
//

import UIKit

let mainWidth = UIScreen.main.bounds.width
let mainHeight = UIScreen.main.bounds.height

class ViewController: UIViewController, UICollisionBehaviorDelegate {

    var animator: UIDynamicAnimator!
    var collisionBehavior: UICollisionBehavior!
    var gravityBehavior: UIGravityBehavior!
    var dynamicItemBehavior: UIDynamicItemBehavior?
    var collisionMode: UICollisionBehavior.Mode = []

    var imageArrayRoad: [UIImage]?
    var imageArrayPlane: [UIImage]?
    var imageArrayTree: [UIImage]?
    var imageArrayBird: [UIImage]?
    
    var score: Int = 0
   // var barrierView: [UIImageView]?
    //var animator:UIDynamicAnimator
    
    @IBOutlet weak var topLeftView: UIImageView!
    @IBOutlet weak var topRightView: UIImageView!
    @IBOutlet weak var bottomView: UIImageView!
    
    @IBOutlet weak var plane1: UIImageView!
    @IBOutlet weak var bird1: UIImageView!
    @IBOutlet weak var road1: UIImageView!
    @IBOutlet weak var tree1: UIImageView!
    
    @IBOutlet weak var scoreDisplay: UILabel!

    
    //func updateScoreDisplay() {
     //   scoreDisplay?.text = "\(score)"
    //}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    //    updateScoreDisplay()
        
        
        
        let birdImage = UIImageView(image: UIImage(named: "bird1.png"))
        birdImage.frame = UIScreen.main.bounds
        self.view.addSubview(birdImage)
        self.view.bringSubviewToFront(birdImage)
        //self.birdArray.append(birdImage)
        
        /*let planeView = UIImageView(image: UIImage(named: "plane1.png"))
        planeView.frame = UIScreen.main.bounds
        self.view.addSubview(planeView)
        self.view.bringSubviewToFront(planeView)*/
         
       /* let coinView = UIImageView(image: UIImage(named: "coin1.png"))
        coinView.frame = UIScreen.main.bounds
        self.view.addSubview(coinView)
       // self.view.bringSubviewToFront(coinView)
        
        let treeView = UIImageView(image: UIImage(named: "tree1.png"))
        treeView.frame = UIScreen.main.bounds
        self.view.addSubview(treeView)
       // self.view.bringSubviewToFront(treeView)
         
        let roadView = UIImageView(image: UIImage(named: "road1.png"))
        roadView.frame = UIScreen.main.bounds
        self.view.addSubview(roadView)
         
        /*for (oneSubView) in self.view.subviews {
            if (oneSubView == birdView) {
                oneSubView.alpha = 0.2
            }
        }*/ */
        

        
        func gameStart() {//list other functions beneath
            score = 0
            //planeStart()
            //roadStart()
            //treeStart()
            birdStart()
            //coinStart()
            behaviorFunctions()
            
            let timeLimit = DispatchTime.now() + 20
            DispatchQueue.main.asyncAfter(deadline: timeLimit) {
                for view in self.view.subviews {
                    view.removeFromSuperview()
                }
                
                let gameFinish = UIImageView(image: UIImage(named: "game_over.jpg"))
                gameFinish.frame = CGRect(x: 0, y:0, width: mainWidth, height: mainHeight)
                self.view.addSubview(gameFinish)
                
                let scoreDisplay = UILabel()
                scoreDisplay.text = "Score: \(self.score)"
                scoreDisplay.textColor = UIColor.red
                scoreDisplay.frame = CGRect(x: mainWidth / 2 - 200, y: mainHeight - 400, width: 247, height: 100)
                self.view.addSubview(scoreDisplay)
                
                /*let gameReplay = UIButton()
                 gameReplay.frame = CGRect(x: mainWidth / 2 - 150, y: mainHeight / 2 - 50, width: 247, height: 100)
                 gameReplay.addTarget(self, action: gameReplay, for: .touchUpInside)
                 self.view.addSubview(gameReplay)*/
            }
        }
        
        func behaviorFunctions() {
            dynamicItemBehavior = UIDynamicItemBehavior(items: [])
            collisionBehavior = UICollisionBehavior(items: [bird1, plane1])
            collisionBehavior.translatesReferenceBoundsIntoBoundary = true
            //collisionBehavior.collisionMode = UICollisionBehavior.Mode.boundaries
            collisionBehavior.addBoundary(withIdentifier: "plane1" as NSCopying, for: UIBezierPath(rect: plane1.frame))
            animator.addBehavior(dynamicItemBehavior!)
            animator.addBehavior(collisionBehavior)
            
            collisionBehavior.action = {
                for birdo in self {
                    if(self.plane1.frame.intersects(self.bird1.frame)){
                        self.score = self.score - 50
                    }
                }
        }
            }
            
            
        func randomNumber(Min: Int, Max: Int) -> Int {
            if Min - Max < 0 {
                return Int(arc4random_uniform(UInt32(Max-Min)) + UInt32(Min))
            }
            else {
                return Int(arc4random_uniform(UInt32(Min-Max)) + UInt32(Min))
            }
        }
            

            
        func birdStart() {
            var birdArray: [UIImage] = [UIImage(named: "bird1")!]
            for i in 1 ... 6 {
                birdArray += [UIImage(named: "birdo\(i)")!]
            }
            
            let birdImages = UIImage.animatedImage(with: birdArray, duration: 2)
            let birdTime = Int(randomNumber(Min: 3, Max: 8))
            for _ in 1 ... birdTime {
                let birdTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 15))
                let birdSpeed = Double(randomNumber(Min: 100, Max: 400))
                let birdHeight = CGFloat(Float(randomNumber(Min: 0, Max: Int(Float(mainHeight - 100)))))
                DispatchQueue.main.asyncAfter(deadline: birdTimer) {
                    let birdCollection = UIImageView(image: birdImages)
                    birdCollection.frame = CGRect(x: mainWidth, y: birdHeight, width:100, height: 100)
                    self.view.addSubview(birdCollection)
                    self.dynamicItemBehavior!.addItem(birdCollection)
                    self.dynamicItemBehavior!.addLinearVelocity(CGPoint(x: -birdSpeed, y: 0), for: birdCollection)
                    self.collisionBehavior.addItem(birdCollection)
                    //self.imageArrayBird.append(birdCollection) - needs to be fixed?
                    DispatchQueue.main.asyncAfter(deadline: birdTimer + Double(ceil(Float(mainWidth) / Float(birdSpeed))) + 1) {
                        self.dynamicItemBehavior!.removeItem(birdCollection)
                        self.collisionBehavior.removeItem(birdCollection)
                        birdCollection.removeFromSuperview()
                        
                    }
            }
        }
    }

        func gameRestart(sender: UIButton!) {
            for view in self.view.subviews {
                view.removeFromSuperview()
            }
            gameStart()
        }

    imageArrayRoad = [UIImage(named: "road1.png"),
                        UIImage(named: "road2.png"),
                        UIImage(named: "road3.png"),
                        UIImage(named: "road4.png"),
                        UIImage(named: "road5.png"),
                        UIImage(named: "road6.png"),
                        UIImage(named: "road7.png"),
                        UIImage(named: "road8.png"),
                        UIImage(named: "road9.png"),
                        UIImage(named: "road10.png"),
                        UIImage(named: "road11.png"),
                        UIImage(named: "road12.png"),
                        UIImage(named: "road13.png"),
                        UIImage(named: "road14.png"),
                        UIImage(named: "road15.png"),
                        UIImage(named: "road16.png"),
                        UIImage(named: "road17.png"),
                        UIImage(named: "road18.png"),
                        UIImage(named: "road19.png")] as? [UIImage]
                
    road1?.image = UIImage.animatedImage(with: imageArrayRoad!, duration: 1)
                
    imageArrayPlane = [UIImage(named: "plane1.png"),
                        UIImage(named: "plane2.png"),
                        UIImage(named: "plane3.png"),
                        UIImage(named: "plane4.png"),
                        UIImage(named: "plane5.png"),
                        UIImage(named: "plane6.png"),
                        UIImage(named: "plane7.png"),
                        UIImage(named: "plane8.png"),
                        UIImage(named: "plane9.png"),
                        UIImage(named: "plane10.png"),
                        UIImage(named: "plane11.png"),
                        UIImage(named: "plane12.png"),
                        UIImage(named: "plane13.png"),
                        UIImage(named: "plane14.png"),
                        UIImage(named: "plane15.png")] as? [UIImage]
                
    plane1?.image = UIImage.animatedImage(with: imageArrayPlane!, duration: 1)
                
    imageArrayTree = [UIImage(named: "tree1.png"),
                        UIImage(named: "tree2.png"),
                        UIImage(named: "tree3.png"),
                        UIImage(named: "tree4.png"),
                        UIImage(named: "tree5.png"),
                        UIImage(named: "tree6.png"),
                        UIImage(named: "tree7.png"),
                        UIImage(named: "tree8.png"),
                        UIImage(named: "tree9.png"),
                        UIImage(named: "tree10.png"),
                        UIImage(named: "tree11.png"),
                        UIImage(named: "tree12.png"),
                        UIImage(named: "tree13.png"),
                        UIImage(named: "tree14.png"),
                        UIImage(named: "tree15.png"),
                        UIImage(named: "tree16.png"),
                        UIImage(named: "tree17.png")] as? [UIImage]
                
    tree1?.image = UIImage.animatedImage(with: imageArrayTree!, duration: 1)
    
    imageArrayBird = [UIImage(named: "bird1.png"),
                        UIImage(named: "bird2.png"),
                        UIImage(named: "bird3.png"),
                        UIImage(named: "bird4.png"),
                        UIImage(named: "bird5.png"),
                        UIImage(named: "bird6.png"),
                        UIImage(named: "bird7.png"),
                        UIImage(named: "bird8.png"),
                        UIImage(named: "bird9.png"),
                        UIImage(named: "bird10.png")] as? [UIImage]
                
    bird1?.image = UIImage.animatedImage(with: imageArrayBird!, duration: 1)
        
        //UIView.animate(withDuration: 3, delay: 1.0, options: [UIView.AnimationOptions.repeat, .curveEaseInOut], animations:{
            //self.bird1.center.x += self.view.bounds.width
        //})
        

    
    
    }

    /*override func viewWillLayoutSubviews() {
        
        if UIDevice.current.orientation == UIDeviceOrientation.landscapeLeft || UIDevice.current.orientation == UIDeviceOrientation.landscapeRight {
            
            var rect = topLeftView.frame
            rect.size.width = 254
            rect.size.height = 130
            topLeftView.frame = rect
            
            rect = topRightView.frame
            rect.origin.x = 294
            rect.size.width = 254
            rect.size.height = 130
            topRightView.frame = rect
            
            rect = bottomView.frame
            rect.origin.y = 170
            rect.size.width = 528
            rect.size.height = 130
            bottomView.frame = rect
            
        }else {
            
            var rect = topLeftView.frame
            rect.size.width = 130
            rect.size.height = 254
            topLeftView.frame = rect
            
            rect = topRightView.frame
            rect.origin.x = 170
            rect.size.width = 130
            rect.size.height = 254
            topRightView.frame = rect
            
            rect = bottomView.frame
            rect.origin.x = 295
            rect.size.width = 280
            rect.size.height = 254
            bottomView.frame = rect
        }
    } */
    
    

    override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    }
}
   // }

    //@IBAction func playGame() {
        
       // let alert = UIAlertController(title: "Play Game!", message: nil, preferredStyle: .alert)
        
       // let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        //alert.addAction(action)
        
        //present(alert, animated: true, completion: nil)
  //  }
    


